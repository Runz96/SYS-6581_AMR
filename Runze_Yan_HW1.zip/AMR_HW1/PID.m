%% PID

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Code by: Runze Yan
% AMR 2019 
% Date: 09/24/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [output, integ, pre_error] = PID(integ, mea_value, pre_error, ref)

%Kp = 0.3;
%Ki = 0.15;
%Kd = 0.3;
Kp = 0.003;
Ki = 0.005;
Kd = 0;

error = ref - mea_value;
integ = integ + error;
deriv = error - pre_error;
output = Kp * error + Ki * integ + Kd * deriv;
pre_error = error;
 
end