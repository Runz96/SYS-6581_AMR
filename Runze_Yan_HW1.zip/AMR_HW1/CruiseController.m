clear
close all
clc

%% Parameters

% Workspace Size
xlim([0 200])
ylim([0 200])

%Initialize a vector of positions for the robot
x=[]; 
y=[];

% Max speed
speed_max = 5;

% Max steering
steering_max = pi/4;

%% Robot Initial Pose

x(1) = 100;
y(1) = 100;

% Initial Orientation 
theta(1) = pi*unifrnd(-1,1,1);

% Initial Speed
vel(1) = 0;

%% Robot Final Pose
xg = unifrnd(0,200,1,3);
yg = unifrnd(0,200,1,3);
plot(xg, yg, '*');
hold on;
    
%% Move Robot

% Number of steps of the simualtion
nstep = 10000;

% Time step
dt = 0.1;

% Parameter
Kv = 0.5;
Kh = 0.5;
i = 1;
g = 0;
integ(1) = 0;
pre_error(1) = 0;
u(i) = 0;
ref = 3;
f = 0.2;

while(g < 3)
    u1 = xg(g+1) - x(i);
    u2 = yg(g+1) - y(i);
    [u(i+1), integ(i+1), pre_error(i+1)] = PID(integ(i), vel(i), pre_error(i), ref);
    vel(i+1) = vel(i) + u(i) * dt - 0.01 * vel(i);
    if(vel(i) > speed_max)
        vel(i) = 5;
    end
    
    theta_rel = atan2(u2, u1);
    x(i+1) = x(i) + vel(i) * cos(theta(i)) * dt;
    y(i+1) = y(i) + vel(i) * sin(theta(i)) * dt;
    error = theta_rel - theta(i);
    steering = Kh * atan2(sin(error), cos(error));
    
    if(steering > steering_max)
        steering = pi/4;
    end

    if(steering < -steering_max)
        steering = - pi/4;
    end
    
    theta(i+1) = theta(i) + steering * dt;
    robot = SquareRobot(x(i),y(i),theta(i));
    plot(robot(:,1),robot(:,2),'-',x,y,'-');
    xlim([0 200])
    ylim([0 200])
    pause(0.01)
    if(x(i)< xg(g+1) + f && x(i)> xg(g+1) - f && y(i) < yg(g+1) + f && y(i) > yg(g+1) - f)
        fprintf('Reach the Goal\r\n');
        g = g + 1;
    
    end
    
    i = i + 1;
    
end
hold off
plot(vel);
xlabel('Time/0.1s');
ylabel('Velocity');
title('Velocity of the robot');