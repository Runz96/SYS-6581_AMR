clear
close all
clc

%% Parameters

% Workspace Size
xlim([0 200])
ylim([0 200])

%Initialize a vector of positions for the robot
x=[]; 
y=[];

% Max speed
speed_max = 5;

% Initial speed
vel(1) = 0;

%% Robot Initial Pose

x(1) = unifrnd(0,200,1);
y(1) = unifrnd(0,200,1);

% Initial Orientation 
theta(1) = pi*unifrnd(-1,1,1);

%% Robot Final Pose
xg = 100;
yg = 100;
    
%% Move Robot

% Number of steps of the simualtion
nstep = 400;

% Time step
dt = 0.1;

% Parameter
Kh = 0.5;
integ(1) = 0;
pre_error(1) = 0;
u(1) = 0;
ref = 75;



for i = 1:nstep
    u1 = xg - x(i);
    u2 = yg - y(i);
    dis(i) = sqrt(u1^2 + u2^2);
    [vel(i+1), integ(i+1), pre_error(i+1)] = PID(integ(i), dis(i), pre_error(i), ref);
    %[vel(i+1), integ(i+1), pre_error(i+1)] = PID(integ(i), vel(i), pre_error(i), ref);
    %vel = vel(i) + Kv * integ(i-1);
    theta_rel = atan2(u2, u1);
    x(i+1) = x(i) + vel(i) * cos(theta(i)) * dt;
    y(i+1) = y(i) + vel(i) * sin(theta(i)) * dt;
    error = theta_rel - theta(i);
    steering = Kh * atan2(sin(error), cos(error));
    theta(i+1) = theta(i) + steering * dt;
    
    robot = SquareRobot(x(i),y(i),theta(i));
    plot(robot(:,1),robot(:,2),'-',x,y,'-');
    hold on
    xlim([0 200])
    ylim([0 200])
    pause(0.01)

end
hold off
plot(vel);
xlabel('Time/0.1s');
ylabel('Velocity');
title('Velocity of the robot');