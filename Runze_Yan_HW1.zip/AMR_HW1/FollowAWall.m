clear
close all
clc

%% Parameters

% Workspace Size
xlim([0 200])
ylim([0 200])

%Velocity (constant for this demo example) 
vel = 5;

%Initialize a vector of positions for the robot
x=[]; 
y=[];

%% Robot Initial Pose
x(1) = 100;
y(1) = 100;

% Max steering
steering_max = pi/4;

% Initial Orientation 
theta(1) = pi*unifrnd(-1,1,1);

%% Aim Line
L = [3, 2, -450];
xg = [0 200];
yg = -(L(1)*xg+L(3))/L(2);
plot(xg, yg, '-');
hold on 
    
%% Move Robot

%number of steps of the simualtion
nstep = 400;

%time step
dt = 0.2;

% parameter
Kd = 0.06;
Kh = 1;
 
for i = 1:nstep
    d(i) = L * [x(i), y(i), 1]';
    theta_rel = atan2(-L(1), L(2));
    error = theta_rel - theta(i);
    steering = -Kd * d(i) + Kh * atan2(sin(error), cos(error));
    x(i+1) = x(i) + vel * cos(theta(i)) * dt;
    y(i+1) = y(i) + vel * sin(theta(i)) * dt; 
    if(steering > steering_max)
        steering = pi/4;
    end

    if(steering < -steering_max)
        steering = - pi/4;
    end
    
    theta(i+1) = theta(i) + steering * dt;
    robot = SquareRobot(x(i+1),y(i+1),theta(i+1));
    plot(robot(:,1),robot(:,2),'-',x,y,'-');
    xlim([0 200])
    ylim([0 200])
    pause(0.01)
    
end
hold off
plot(d);
xlabel('Time/0.1s');
ylabel('Distance/m');
title('Distance between robot and line');