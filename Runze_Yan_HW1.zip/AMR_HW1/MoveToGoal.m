clear
close all
clc

%% Parameters

% Workspace Size
xlim([0 200])
ylim([0 200])

%Initialize a vector of positions for the robot
x=[]; 
y=[];

% Initial speed
v(1) = 0;

% Max steering
steering_max = pi/4;

% Max speed
speed_max = 5;

%% Robot Initial Pose

x(1) = 118;
y(1) = 125;

% Initial Orientation 
theta(1) = pi*unifrnd(-1,1,1);

%% Robot Final Pose

xg = unifrnd(0,200,1);
yg = unifrnd(0,200,1);
plot(xg, yg, '*');
hold on;
    
%% Move Robot

% Number of steps of the simualtion
nstep = 10000;

% Time step
dt = 0.1;

% Parameter
Kv = 0.1;
Kh = 0.5;
f = 0.2;

for i = 1:nstep
    u1 = xg - x(i);
    u2 = yg - y(i);
    vel(i) = Kv * sqrt(u1^2 + u2^2);
    vel(1) = 0;
    if(vel(i) > speed_max)
        vel(i) = 5;
    end
    
    theta_rel = atan2(u2, u1);
    x(i+1) = x(i) + vel(i) * cos(theta(i)) * dt;
    y(i+1) = y(i) + vel(i) * sin(theta(i)) * dt;
    error = theta_rel - theta(i);
    steering = Kh * atan2(sin(error), cos(error));
    if(steering > steering_max)
        steering = pi/4;
    end

    if(steering < -steering_max)
        steering = - pi/4;
    end
    
    theta(i+1) = theta(i) + steering * dt;  
    robot = SquareRobot(x(i),y(i),theta(i));
    plot(robot(:,1),robot(:,2),'-',x,y,'-');
    xlim([0 200])
    ylim([0 200])
    pause(0.01)
    if(x(i)< xg + f && x(i)> xg - f && y(i) < yg + f && y(i) > yg - f)
        fprintf('Reach the Goal\r\n');
        vel(i) = 0;
        break
    
    end
    
end
hold off
plot(vel);
xlabel('Time/0.1s');
ylabel('Velocity');
title('Velocity of the robot');