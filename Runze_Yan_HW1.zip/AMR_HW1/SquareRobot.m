function [robot] = SquareRobot(x,y,theta)

center = [x y];

% Robot triangle shape

a = [-5 -5];
b = [5 5];
c = [-5 5];
d = [5 -5];

% Max steering angle
theta_max = pi/4;
if(theta > theta_max)
    theta = pi/4;
end

if(theta < -theta_max)
    theta = - pi/4;
end

% Rotation Matrix

rotmat = [cos(theta) -sin(theta); sin(theta) cos(theta)];

rota = (rotmat * (a'));
rotb = (rotmat * (b'));
rotc = (rotmat * (c'));
rotd = (rotmat * (d'));

% Final Robot Configuration after transformation

robot1 = [rota(1) + center(1), rota(2) + center(2)];
robot2 = [rotb(1) + center(1), rotb(2) + center(2)];
robot3 = [rotc(1) + center(1), rotc(2) + center(2)];
robot4 = [rotd(1) + center(1), rotd(2) + center(2)];

robot = [robot3;robot2;robot4;robot1;robot3];

end


