clear
close all
clc

%% Parameters

% Workspace Size
xlim([0 200])
ylim([0 200])

%Initialize a vector of positions for the robot
x=[]; 
y=[];

%% Robot Initial Pose

x(1) = 100;
y(1) = 100;

% Initial Orientation 
theta(1) = pi * unifrnd(-1,1,1);

%% Robot Finial Pose

x(2) = x(1) + 18;
y(2) = x(1) + 25;

% Initial Orientation 
theta(2) = theta(1) + pi/(5 + 10);

%% Initial Configuration

robot = SquareRobot(x(1),y(1),theta(1));
plot(robot(:,1),robot(:,2),'-');
hold on
xlim([0 100])
ylim([0 100])
    
%% Final Configuration

robot = SquareRobot(x(2),y(2),theta(2));
plot(robot(:,1),robot(:,2),'-');
xlim([0 200])
ylim([0 200])

