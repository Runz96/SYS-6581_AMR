nstep = 400;
integ(1) = 0;
mea_value(1) = 0;
pre_error(1) = 0;
ic(1) = 1;

for i = 1:nstep
   [mea_value(i+1), integ(i+1), pre_error(i+1)] = PID(integ(i), mea_value(i), pre_error(i));
   fprintf('%d ', mea_value(i+1));
   fprintf('\r\n');
end